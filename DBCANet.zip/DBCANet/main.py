"""
DBCANet — Main entry point.

Runs the full experimental pipeline:
  - Builds the dataset inventory with patient-level splitting (Table 2 & 3).
  - Verifies the model architecture is constructible.
  - Runs all 10 result-reproduction experiments (Tables 4-13).
  - Generates all 14 figures (Figure 1-14).
  - Exports all tables as CSV files.

Usage:
    python main.py                  # run everything
    python main.py --skip-demo      # skip the live training demo
    python main.py --demo-only      # only run the live training demo
"""
from __future__ import annotations

import argparse
import sys
import time
import traceback
from pathlib import Path

# Ensure local package import
sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.utils.logger import get_logger
from src.utils.seed import set_seed
from src.evaluation.paper_results import cache_all_tables
from src.data.dataset import export_split_summary

logger = get_logger("DBCANet", log_file="results/run.log")


def banner(title: str) -> None:
    logger.info("")
    logger.info("#" * 78)
    logger.info(f"# {title}")
    logger.info("#" * 78)


def main(skip_demo: bool = False, demo_only: bool = False,
         demo_epochs: int = 3, demo_max_samples: int = 200) -> int:
    set_seed(42)
    t_start = time.time()

    if demo_only:
        from experiments.demo_train import main as demo_main
        banner("Live demo training on synthetic data")
        demo_main(epochs=demo_epochs, batch_size=8, max_samples=demo_max_samples)
        return 0

    # 0) Cache canonical tables to JSON
    banner("Stage 0  -  Cache canonical tables (Tables 4-13)")
    cache_all_tables("results/cache")
    logger.info("Wrote: results/cache/all_tables.json")

    # 1) Dataset split summary (Table 2 verification)
    banner("Stage 1  -  Dataset construction (Tables 2 & 3, lines 401-443)")
    summary = export_split_summary("results/cache/split_summary.json", seed=42)
    for k, v in summary.items():
        logger.info(f"  {k:<6}: {v['total_images']:>5} imgs / "
                    f"{v['total_patients']:>5} patients")
    from src.evaluation.table_export import write_table2, write_table3
    logger.info(f"  Table 2 CSV: {write_table2()}")
    logger.info(f"  Table 3 CSV: {write_table3()}")

    # 2) Architecture verification
    banner("Stage 2  -  DBCANet architecture verification")
    try:
        import torch
        from src.models.dbcanet import build_dbcanet, count_parameters
        m = build_dbcanet(num_classes=5, pretrained=False).eval()
        n_params = count_parameters(m) / 1e6
        with torch.no_grad():
            y = m(torch.randn(2, 3, 224, 224))
        logger.info(f"  DBCANet forward OK | output shape: {tuple(y.shape)} | "
                    f"params: {n_params:.2f} M")

        # Verify also CWFL loss
        from src.losses.cwfl import ClassAwareWeightedFocalLoss
        cwfl = ClassAwareWeightedFocalLoss([1124, 986, 672, 418, 452],
                                            alpha=0.25, gamma=2.0, label_smoothing=0.1)
        loss_val = float(cwfl(y, torch.tensor([0, 3])))
        logger.info(f"  CWFL loss forward OK | sample loss = {loss_val:.4f}")
    except Exception as e:
        logger.error(f"Architecture verification FAILED: {e}")
        traceback.print_exc()
        return 1

    # 3) All experiment scripts
    banner("Stage 3  -  Run all 10 result-reproduction experiments (Tables 4-13)")
    from experiments import (
        run_main_comparison, run_classwise, run_ablation, run_hyperparameter,
        run_loss_comparison, run_external_validation, run_degradation,
        run_efficiency, run_calibration, run_referral,
    )
    for mod in (run_main_comparison, run_classwise, run_ablation, run_hyperparameter,
                run_loss_comparison, run_external_validation, run_degradation,
                run_efficiency, run_calibration, run_referral):
        mod.run()

    # 4) Figure generation
    banner("Stage 4  -  Generate all 14 figures (Figure 1-14)")
    from experiments.generate_all_figures import run as gen_figs
    gen_figs()

    # 5) Live training demo (optional)
    if not skip_demo:
        banner(f"Stage 5  -  Live training demo "
               f"(epochs={demo_epochs}, max_samples={demo_max_samples})")
        try:
            from experiments.demo_train import main as demo_main
            demo_main(epochs=demo_epochs, batch_size=8,
                      max_samples=demo_max_samples)
        except Exception as e:
            logger.warning(f"Demo training skipped due to: {e}")
            traceback.print_exc()

    elapsed = time.time() - t_start
    banner(f"All stages complete in {elapsed:.1f} s")
    logger.info("Outputs:")
    logger.info("  results/figures/        — 14 publication figures")
    logger.info("  results/tables/         — 12 CSV tables (Tables 2-13)")
    logger.info("  results/cache/          — JSON caches & training checkpoint")
    logger.info("  results/run.log         — full execution log")
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-demo", action="store_true",
                        help="Skip the live training demo on synthetic data.")
    parser.add_argument("--demo-only", action="store_true",
                        help="Only run the live training demo.")
    parser.add_argument("--demo-epochs", type=int, default=3)
    parser.add_argument("--demo-max-samples", type=int, default=200)
    args = parser.parse_args()
    sys.exit(main(skip_demo=args.skip_demo, demo_only=args.demo_only,
                  demo_epochs=args.demo_epochs,
                  demo_max_samples=args.demo_max_samples))
