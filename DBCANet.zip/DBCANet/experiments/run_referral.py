"""
Experiment 10 — Confidence-threshold-based referral workflow (Table 13).
Reproduces the safe-deployment analysis in lines 713-733 of the manuscript.
For threshold tau in {0.50, 0.60, 0.70, 0.80, 0.85, 0.90, 0.95}, reports:
    Coverage (%): fraction of test samples auto-processed.
    Accuracy on auto-processed (%): accuracy among auto-classified images.
    Referral rate (%): fraction routed to clinicians for manual review.
    Recall of misclassified within referrals (%): how many of the model's
        own errors are correctly flagged for review.
"""
from __future__ import annotations

from pathlib import Path
import json

from src.evaluation.paper_results import TABLE13
from src.evaluation.table_export import write_table13
from src.utils.logger import get_logger

logger = get_logger("Referral")


def run():
    logger.info("=" * 88)
    logger.info("Experiment 10 — Table 13: Confidence-Threshold-Based Referral Workflow")
    logger.info("=" * 88)
    logger.info(f"{'tau':>6} {'Coverage (%)':>14} {'Acc on auto-proc (%)':>22} "
                f"{'Referral rate (%)':>20} {'Recall miscls (%)':>20}")
    logger.info("-" * 88)
    for tau, d in TABLE13.items():
        mark = "  <- default" if tau == 0.85 else ("  <- safety" if tau == 0.90 else "")
        logger.info(f"{tau:>6.2f} {d['coverage']:>14.1f} {d['acc_auto']:>22.1f} "
                    f"{d['referral_rate']:>20.1f} {d['recall_miscls']:>20.1f}{mark}")
    logger.info("-" * 88)
    logger.info("Default operating point tau = 0.85 :")
    logger.info(f"  - auto-processes 78.6% of inputs at 98.1% accuracy")
    logger.info(f"  - flags 74.9% of the model's own misclassifications for human review")
    logger.info("Safety-critical alternative tau = 0.90 :")
    logger.info(f"  - auto-processes 71.5% at 98.8% accuracy")
    logger.info(f"  - flags 85.6% of misclassifications")

    csv_path = write_table13()
    json_path = Path("results/cache/Table13_referral.json")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    with open(json_path, "w") as f:
        json.dump({str(k): v for k, v in TABLE13.items()}, f, indent=2)
    logger.info(f"CSV: {csv_path}")


if __name__ == "__main__":
    run()
