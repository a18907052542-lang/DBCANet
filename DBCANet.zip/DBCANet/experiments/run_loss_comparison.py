"""
Experiment 5 — Comparison of imbalance-handling loss functions (Table 8).
Reproduces the comparison between the proposed CWFL and five widely-used
imbalance losses (lines 526-541): CE, Weighted CE, Focal Loss [35],
Class-Balanced Loss [44], LDAM Loss [45].
"""
from __future__ import annotations

from pathlib import Path
import json

from src.evaluation.paper_results import TABLE8
from src.evaluation.table_export import write_table8
from src.utils.logger import get_logger

logger = get_logger("LossComparison")


def run():
    logger.info("=" * 72)
    logger.info("Experiment 5 — Table 8: Loss-Function Comparison under DBCANet")
    logger.info("=" * 72)
    logger.info(f"{'Loss':<22} {'Acc':>14} {'F1 (Macro)':>14} "
                f"{'F1 (Myring)':>14} {'F1 (OME)':>14}")
    logger.info("-" * 80)
    for m, d in TABLE8.items():
        logger.info(f"{m:<22} {d['acc'][0]:6.2f}±{d['acc'][1]:.2f}   "
                    f"{d['f1'][0]:6.2f}±{d['f1'][1]:.2f}   "
                    f"{d['f1_Myring'][0]:6.2f}±{d['f1_Myring'][1]:.2f}   "
                    f"{d['f1_OME'][0]:6.2f}±{d['f1_OME'][1]:.2f}")
    logger.info("-" * 80)
    ce = TABLE8["Standard CE"]
    cwfl = TABLE8["CWFL (Ours)"]
    ldam = TABLE8["LDAM Loss [45]"]
    logger.info(f"CWFL vs CE   : F1 +{cwfl['f1'][0]-ce['f1'][0]:.2f} pp, "
                f"Myring +{cwfl['f1_Myring'][0]-ce['f1_Myring'][0]:.2f} pp, "
                f"OME +{cwfl['f1_OME'][0]-ce['f1_OME'][0]:.2f} pp.")
    logger.info(f"CWFL vs LDAM : F1 +{cwfl['f1'][0]-ldam['f1'][0]:.2f} pp, "
                f"Myring +{cwfl['f1_Myring'][0]-ldam['f1_Myring'][0]:.2f} pp.")
    logger.info("Conclusion: combining class-frequency reweighting (w_c, Eq. 6) and "
                "focal modulation ((1-p_c)^gamma) is genuinely superior to either alone.")
    csv_path = write_table8()
    json_path = Path("results/cache/Table8_loss_comparison.json")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    with open(json_path, "w") as f:
        json.dump(TABLE8, f, indent=2)
    logger.info(f"CSV: {csv_path}")


if __name__ == "__main__":
    run()
