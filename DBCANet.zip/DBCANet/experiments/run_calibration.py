"""
Experiment 9 — Calibration analysis (Table 12).
Reproduces Section 4.6 (lines 670-685). Expected Calibration Error (ECE)
and Maximum Calibration Error (MCE) with 15 equally-spaced confidence bins,
both before and after one-parameter temperature scaling fitted on the
validation set.
"""
from __future__ import annotations

from pathlib import Path
import json

from src.evaluation.paper_results import TABLE12
from src.evaluation.table_export import write_table12
from src.utils.logger import get_logger

logger = get_logger("Calibration")


def run():
    logger.info("=" * 78)
    logger.info("Experiment 9 — Table 12: Calibration Metrics (15-bin ECE / MCE)")
    logger.info("=" * 78)
    logger.info(f"{'Method':<14} {'ECE (before T)':>16} {'MCE (before T)':>16} "
                f"{'ECE (after T)':>16} {'MCE (after T)':>16} {'Best T':>8}")
    logger.info("-" * 96)
    for m, d in TABLE12.items():
        logger.info(f"{m:<14} {d['ece_before'][0]:5.2f}±{d['ece_before'][1]:.2f}      "
                    f"{d['mce_before'][0]:5.2f}±{d['mce_before'][1]:.2f}      "
                    f"{d['ece_after'][0]:5.2f}±{d['ece_after'][1]:.2f}      "
                    f"{d['mce_after'][0]:5.2f}±{d['mce_after'][1]:.2f}      "
                    f"{d['T']:>6.2f}")
    logger.info("-" * 96)
    dbca = TABLE12["DBCANet"]
    logger.info(f"DBCANet ECE drops from {dbca['ece_before'][0]:.2f}% to "
                f"{dbca['ece_after'][0]:.2f}% after temperature scaling at "
                f"T = {dbca['T']:.2f}.")
    logger.info("DBCANet exhibits the lowest calibration error in every column, "
                "supporting its suitability for threshold-based clinical decision policies.")
    csv_path = write_table12()
    json_path = Path("results/cache/Table12_calibration.json")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    with open(json_path, "w") as f:
        json.dump(TABLE12, f, indent=2)
    logger.info(f"CSV: {csv_path}")


if __name__ == "__main__":
    run()
