"""
Demo training script — proves the DBCANet pipeline is end-to-end runnable.
Trains the real DBCANet model on the synthetic dataset for a small number
of epochs and reports validation metrics. Intended as a sanity check; the
full 100-epoch training reported in the manuscript was run on a single
NVIDIA RTX 3090 GPU.

Usage:
    python -m experiments.demo_train --epochs 3 --batch-size 8 --max-samples 200
"""
from __future__ import annotations

import argparse
import time
from pathlib import Path

import torch

from src.data.dataset import (
    build_sample_inventory, patient_level_split, TympanicMembraneDataset,
    class_counts,
)
from src.data.augmentation import build_train_transform, build_eval_transform
from src.losses.cwfl import ClassAwareWeightedFocalLoss
from src.models.dbcanet import build_dbcanet, count_parameters
from src.training.trainer import TrainConfig, train, evaluate
from src.utils.logger import get_logger
from src.utils.seed import set_seed

logger = get_logger("DemoTrain")


def main(epochs: int = 3, batch_size: int = 8, max_samples: int = 200,
         seed: int = 42, image_size: int = 224):
    set_seed(seed)
    logger.info("=" * 72)
    logger.info("Demo training run on synthetic data — proves pipeline runnability.")
    logger.info("For full results matching Table 4, train on the real dataset")
    logger.info("for 100 epochs (see configs/default.yaml and main.py).")
    logger.info("=" * 72)

    # Build dataset
    inv = build_sample_inventory(seed=seed)
    train_s, val_s, test_s = patient_level_split(inv, (0.7, 0.1, 0.2), seed=seed)
    # Restrict size for demo speed
    if max_samples is not None:
        train_s = train_s[:max_samples]
        val_s = val_s[:max(40, max_samples // 5)]
        test_s = test_s[:max(40, max_samples // 5)]
    counts = class_counts(train_s)
    logger.info(f"Train: {len(train_s)} | Val: {len(val_s)} | Test: {len(test_s)}")
    logger.info(f"Train per-class counts: {dict(zip(['N','C','O','M','W'], counts))}")

    train_t = build_train_transform(image_size)
    eval_t = build_eval_transform(image_size)
    train_ds = TympanicMembraneDataset(train_s, transform=train_t, synthetic=True,
                                       image_size=image_size)
    val_ds = TympanicMembraneDataset(val_s, transform=eval_t, synthetic=True,
                                     image_size=image_size)
    test_ds = TympanicMembraneDataset(test_s, transform=eval_t, synthetic=True,
                                      image_size=image_size)
    train_loader = torch.utils.data.DataLoader(train_ds, batch_size=batch_size,
                                                shuffle=True, num_workers=0)
    val_loader = torch.utils.data.DataLoader(val_ds, batch_size=batch_size,
                                              shuffle=False, num_workers=0)
    test_loader = torch.utils.data.DataLoader(test_ds, batch_size=batch_size,
                                               shuffle=False, num_workers=0)

    # Build DBCANet (pretrained=False for speed in demo; set True for real training)
    model = build_dbcanet(num_classes=5, pretrained=False)
    n_params = count_parameters(model) / 1e6
    logger.info(f"DBCANet parameters: {n_params:.2f} M")

    loss_fn = ClassAwareWeightedFocalLoss(counts, alpha=0.25, gamma=2.0,
                                          label_smoothing=0.1)
    cfg = TrainConfig(
        epochs=epochs,
        lr=1e-4, weight_decay=5e-4, eta_min=1e-6,
        freeze_backbone_epochs=min(2, epochs - 1),
        backbone_lr_scale=0.1,
        early_stopping_patience=15,
        device="cpu",  # demo runs on CPU; switch to "cuda" for real GPU training
    )

    logger.info("Starting demo training...")
    t0 = time.time()
    state = train(model, train_loader, val_loader, loss_fn, cfg,
                  ckpt_path="results/cache/demo_best.pt", verbose=True)
    elapsed = time.time() - t0
    logger.info(f"Demo training finished in {elapsed:.1f} s")
    logger.info(f"Best val macro-F1: {state.best_val_f1 * 100:.2f}% at epoch {state.best_epoch}")

    # Test evaluation
    test_metrics = evaluate(model, test_loader, cfg.device)
    logger.info(f"Test set: acc = {test_metrics['accuracy'] * 100:.2f}%, "
                f"macro-F1 = {test_metrics['macro_f1'] * 100:.2f}%")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--max-samples", type=int, default=200)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--image-size", type=int, default=224)
    args = parser.parse_args()
    main(epochs=args.epochs, batch_size=args.batch_size,
         max_samples=args.max_samples, seed=args.seed,
         image_size=args.image_size)
