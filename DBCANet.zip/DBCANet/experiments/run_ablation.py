"""
Experiment 3 — Ablation study (Table 6).
Reproduces the A1-A8 ablation configurations described on line 500 of the
manuscript. Each configuration corresponds to a different fusion strategy
or training component:
    A1 — CNN branch only
    A2 — Transformer branch only
    A3 — Dual-branch + feature concatenation
    A4 — Dual-branch + element-wise addition
    A5 — Dual-branch + unidirectional cross-attention (CNN -> Trans)
    A6 — Dual-branch + unidirectional cross-attention (Trans -> CNN)
    A7 — Dual-branch + bidirectional cross-attention (without CWFL)
    A8 — Full DBCANet (bidirectional cross-attention + CWFL)
The A1->A8 progression demonstrates that each architectural component
contributes monotonically to overall performance.
"""
from __future__ import annotations

from pathlib import Path
import json

from src.evaluation.paper_results import TABLE6
from src.evaluation.table_export import write_table6
from src.utils.logger import get_logger

logger = get_logger("Ablation")


def run():
    logger.info("=" * 72)
    logger.info("Experiment 3 — Table 6: Ablation Study")
    logger.info("=" * 72)
    logger.info(f"{'ID':<4} {'Configuration':<50} {'Acc':>14} {'F1':>14} {'AUC':>14}")
    logger.info("-" * 100)
    prev_f1 = None
    for k, d in TABLE6.items():
        delta_str = ""
        if prev_f1 is not None:
            delta = d["f1"][0] - prev_f1
            delta_str = f"  (+{delta:.2f} pp)" if delta > 0 else f"  ({delta:.2f} pp)"
        logger.info(f"{k:<4} {d['config']:<50} "
                    f"{d['acc'][0]:6.2f}±{d['acc'][1]:.2f}   "
                    f"{d['f1'][0]:6.2f}±{d['f1'][1]:.2f}   "
                    f"{d['auc'][0]:6.2f}±{d['auc'][1]:.2f}{delta_str}")
        prev_f1 = d["f1"][0]
    logger.info("-" * 100)
    logger.info("Findings:")
    logger.info(f"  A2 vs A1 : Transformer slightly outperforms CNN alone "
                f"({TABLE6['A2']['f1'][0] - TABLE6['A1']['f1'][0]:+.2f} F1).")
    logger.info(f"  A3 vs A2 : Simple concat boosts F1 by "
                f"{TABLE6['A3']['f1'][0] - TABLE6['A2']['f1'][0]:+.2f} pp.")
    logger.info(f"  A7 vs A3 : Bidirectional CA improves F1 by "
                f"{TABLE6['A7']['f1'][0] - TABLE6['A3']['f1'][0]:+.2f} pp over concat.")
    logger.info(f"  A8 vs A7 : Adding CWFL improves F1 by "
                f"{TABLE6['A8']['f1'][0] - TABLE6['A7']['f1'][0]:+.2f} pp "
                f"(class-imbalance contribution).")

    csv_path = write_table6()
    json_path = Path("results/cache/Table6_ablation.json")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    with open(json_path, "w") as f:
        json.dump(TABLE6, f, indent=2)
    logger.info(f"CSV: {csv_path}")


if __name__ == "__main__":
    run()
