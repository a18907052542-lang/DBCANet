"""
Experiment — Generate all 14 figures from the manuscript.
"""
from __future__ import annotations

from src.visualization.plots import generate_all_figures
from src.utils.logger import get_logger

logger = get_logger("Figures")


def run():
    logger.info("=" * 72)
    logger.info("Generating all 14 figures (Figure 1-14)")
    logger.info("=" * 72)
    paths = generate_all_figures()
    for k, p in paths.items():
        logger.info(f"  {k}: {p}")
    logger.info(f"Total: {len(paths)} figures written to results/figures/")


if __name__ == "__main__":
    run()
