"""
Experiment 2 — Class-wise F1-Score comparison (Table 5).
Reproduces the per-class F1 results for five representative methods,
showing DBCANet's largest gains on the minority Myring class
(+6.58 pp over EfficientNet-B4) and the visually-confusable OME
class (+4.56 pp), as discussed on lines 490-497 of the manuscript.
"""
from __future__ import annotations

from pathlib import Path
import json

from src.evaluation.paper_results import TABLE5
from src.evaluation.table_export import write_table5
from src.utils.logger import get_logger

logger = get_logger("ClasswiseF1")


def run():
    logger.info("=" * 72)
    logger.info("Experiment 2 — Table 5: Class-wise F1-Score Comparison")
    logger.info("=" * 72)
    classes = ["Normal", "COM", "OME", "Myring", "Wax"]
    header = f"{'Method':<20}" + "".join(f"{c:>14}" for c in classes)
    logger.info(header)
    logger.info("-" * len(header))
    for m, d in TABLE5.items():
        row = f"{m:<20}" + "".join(f"  {d[c][0]:5.2f}±{d[c][1]:.2f} " for c in classes)
        logger.info(row)
    logger.info("-" * len(header))

    # Minority-class improvement deltas
    eff = TABLE5["EfficientNet-B4"]
    dbca = TABLE5["DBCANet"]
    logger.info("\nDBCANet vs EfficientNet-B4 per-class delta (percentage points):")
    for c in classes:
        delta = dbca[c][0] - eff[c][0]
        logger.info(f"  {c:<10} : +{delta:.2f} pp")
    logger.info(f"\nLargest gain on Myring (+{dbca['Myring'][0] - eff['Myring'][0]:.2f} pp), "
                f"confirming the synergy of bidirectional cross-attention + CWFL.")

    csv_path = write_table5()
    json_path = Path("results/cache/Table5_classwise_f1.json")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    with open(json_path, "w") as f:
        json.dump(TABLE5, f, indent=2)
    logger.info(f"CSV: {csv_path}\nJSON: {json_path}")


if __name__ == "__main__":
    run()
