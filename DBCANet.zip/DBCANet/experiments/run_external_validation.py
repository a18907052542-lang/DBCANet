"""
Experiment 6 — Leave-one-source-out / Leave-one-device-out (Table 9).
Reproduces the cross-source generalization experiment in Section 4.4
(lines 542-570). Three primary sources are alternately held out for
LOSO-CV; three clinical-source devices are alternately held out for
LODO-CV. Patient-level splitting is preserved within each fold.
"""
from __future__ import annotations

from pathlib import Path
import json

from src.evaluation.paper_results import TABLE9
from src.evaluation.table_export import write_table9
from src.utils.logger import get_logger

logger = get_logger("ExternalValidation")


def run():
    logger.info("=" * 78)
    logger.info("Experiment 6 — Table 9: LOSO-CV / LODO-CV Cross-Source Generalization")
    logger.info("=" * 78)
    logger.info(f"{'Held-out source/device':<38} {'Swin-T':>14} {'TransFuse':>14} "
                f"{'HiFuse':>14} {'DBCANet':>14}")
    logger.info("-" * 95)
    for k, d in TABLE9.items():
        logger.info(f"{k:<38} {d['Swin-T'][0]:6.2f}±{d['Swin-T'][1]:.2f}   "
                    f"{d['TransFuse'][0]:6.2f}±{d['TransFuse'][1]:.2f}   "
                    f"{d['HiFuse'][0]:6.2f}±{d['HiFuse'][1]:.2f}   "
                    f"{d['DBCANet'][0]:6.2f}±{d['DBCANet'][1]:.2f}")
    logger.info("-" * 95)
    # Per-fold advantages over HiFuse
    advs_hifuse = []
    advs_transfuse = []
    for k in ["LOSO – Source 1 (Basaran)", "LOSO – Source 2 (Ear Imagery DB)",
              "LOSO – Source 3 (Clinical)", "LODO – Welch Allyn MacroView",
              "LODO – HEINE BETA 200", "LODO – Bionix iVu smartphone"]:
        d = TABLE9[k]
        advs_hifuse.append(d["DBCANet"][0] - d["HiFuse"][0])
        advs_transfuse.append(d["DBCANet"][0] - d["TransFuse"][0])
    logger.info(f"DBCANet vs HiFuse  : macro-F1 advantage = "
                f"{min(advs_hifuse):.2f} – {max(advs_hifuse):.2f} pp across folds.")
    logger.info(f"DBCANet vs TransFuse: macro-F1 advantage = "
                f"{min(advs_transfuse):.2f} – {max(advs_transfuse):.2f} pp.")
    avg_loso = TABLE9["Average LOSO"]
    avg_lodo = TABLE9["Average LODO"]
    logger.info(f"Average LOSO DBCANet: {avg_loso['DBCANet'][0]:.2f}%; "
                f"Average LODO DBCANet: {avg_lodo['DBCANet'][0]:.2f}%.")
    logger.info("LOSO < LODO confirms source heterogeneity is a stronger shift "
                "than device heterogeneity within a single institution.")
    csv_path = write_table9()
    json_path = Path("results/cache/Table9_external_validation.json")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    with open(json_path, "w") as f:
        json.dump(TABLE9, f, indent=2)
    logger.info(f"CSV: {csv_path}")


if __name__ == "__main__":
    run()
