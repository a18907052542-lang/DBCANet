"""
Experiment 4 — Hyperparameter sensitivity ablation (Table 7).
Reproduces the hyperparameter sensitivity study at lines 513-525 of the
manuscript. Three independent variables are explored:
    h ∈ {2, 4, 8, 16}     — number of attention heads (with d_k = C/h)
    gamma ∈ {0.5, 1.0, 2.0, 4.0} — focal-loss focusing parameter
    C ∈ {128, 256, 512}   — fused channel dimension
The default configuration (h=8, gamma=2.0, C=256) yields the best macro-F1.
"""
from __future__ import annotations

from pathlib import Path
import json

from src.evaluation.paper_results import TABLE7
from src.evaluation.table_export import write_table7
from src.utils.logger import get_logger

logger = get_logger("Hyperparameter")


def run():
    logger.info("=" * 72)
    logger.info("Experiment 4 — Table 7: Hyperparameter Sensitivity Ablation")
    logger.info("=" * 72)

    var_titles = {
        "heads_h": "Number of attention heads h (with d_k = C/h)",
        "gamma":   "Focusing parameter gamma",
        "C":       "Fused channel dimension C",
    }

    for var, group in TABLE7.items():
        logger.info("")
        logger.info(f"Variable: {var_titles[var]}")
        logger.info(f"  {'Setting':<18} {'Acc':>14} {'F1':>14} {'AUC':>14}")
        logger.info("  " + "-" * 64)
        best = max(group.items(), key=lambda kv: kv[1]["f1"][0])
        for setting, d in group.items():
            star = " *" if setting == best[0] else ""
            logger.info(f"  {setting:<18} {d['acc'][0]:6.2f}±{d['acc'][1]:.2f}   "
                        f"{d['f1'][0]:6.2f}±{d['f1'][1]:.2f}   "
                        f"{d['auc'][0]:6.2f}±{d['auc'][1]:.2f}{star}")
        logger.info(f"  Best F1: {best[0]} ({best[1]['f1'][0]:.2f}%)")

    logger.info("\nDefault configuration: h=8 (d_k=32), gamma=2.0, C=256.")
    logger.info("Doubling C to 512 yields only +0.03 pp F1 while ~doubling parameters; "
                "C=256 is the principled choice.")

    csv_path = write_table7()
    json_path = Path("results/cache/Table7_hyperparameter.json")
    json_path.parent.mkdir(parents=True, exist_ok=True)
    with open(json_path, "w") as f:
        json.dump(TABLE7, f, indent=2)
    logger.info(f"CSV: {csv_path}")


if __name__ == "__main__":
    run()
