"""
Loss functions for the DBCANet experiments.
Implements Eq. (5)-(6) at lines 360-369 of the manuscript:

    L_CWFL = - w_c * alpha * (1 - p_c)^gamma * log(p_c)        (Eq. 5)
    w_c    = (N_total / (C * n_c))                              (Eq. 6)

Also implements the five widely-used imbalance losses compared in Table 8:
CE, Weighted CE, Focal Loss [35], Class-Balanced Loss [44], LDAM Loss [45].
"""
from __future__ import annotations

from typing import Optional

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


# ============================================================
#  Class-Aware Weighted Focal Loss (CWFL) — Eq. (5) & (6)
# ============================================================
class ClassAwareWeightedFocalLoss(nn.Module):
    """
    L_CWFL = - w_c * alpha * (1 - p_c)^gamma * log(p_c)
    w_c    = N_total / (C * n_c)
    where p_c is the model's softmax probability for the *true* class c,
    n_c is the number of training samples in class c, N_total is the
    total training set size, and C is the number of classes.
    Label smoothing (coeff 0.1, lines 370-373) is applied on top.
    """

    def __init__(
        self,
        class_counts: list,
        alpha: float = 0.25,
        gamma: float = 2.0,
        label_smoothing: float = 0.1,
        reduction: str = "mean",
    ) -> None:
        super().__init__()
        n_c = torch.tensor(class_counts, dtype=torch.float32)
        N_total = n_c.sum()
        C = len(class_counts)
        w_c = N_total / (C * n_c)                # Eq. (6)
        # Normalize so mean(w_c) = 1 to keep loss scale comparable
        w_c = w_c * (C / w_c.sum())
        self.register_buffer("class_weights", w_c)
        self.alpha = alpha
        self.gamma = gamma
        self.label_smoothing = label_smoothing
        self.reduction = reduction

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        logits  : (B, C) raw classifier outputs.
        targets : (B,)  int64 ground-truth class indices.
        """
        C = logits.shape[-1]
        # Smoothed one-hot targets
        with torch.no_grad():
            one_hot = F.one_hot(targets, C).float()
            if self.label_smoothing > 0:
                one_hot = one_hot * (1 - self.label_smoothing) + self.label_smoothing / C

        log_p = F.log_softmax(logits, dim=-1)
        p = log_p.exp()

        # Focal term computed on the true-class probability per sample
        p_t = (p * one_hot).sum(dim=-1)           # marginal true-class probability
        focal = (1.0 - p_t).clamp(min=1e-8) ** self.gamma   # (1 - p_c)^gamma

        # Cross-entropy with label smoothing
        ce = -(one_hot * log_p).sum(dim=-1)        # (B,)

        # Per-sample class weight w_c (for the *true* class)
        w = self.class_weights[targets]            # (B,)
        loss = w * self.alpha * focal * ce          # Eq. (5)

        if self.reduction == "mean":
            return loss.mean()
        if self.reduction == "sum":
            return loss.sum()
        return loss


# ============================================================
#  Baseline losses for Table 8
# ============================================================
class StandardCrossEntropy(nn.Module):
    """Standard CE with optional label smoothing."""

    def __init__(self, label_smoothing: float = 0.0) -> None:
        super().__init__()
        self.ls = label_smoothing

    def forward(self, logits, targets):
        return F.cross_entropy(logits, targets, label_smoothing=self.ls)


class WeightedCrossEntropy(nn.Module):
    """Class-frequency-weighted CE (w_c = N_total / (C * n_c))."""

    def __init__(self, class_counts: list, label_smoothing: float = 0.0) -> None:
        super().__init__()
        n_c = torch.tensor(class_counts, dtype=torch.float32)
        N_total = n_c.sum()
        C = len(class_counts)
        w = N_total / (C * n_c)
        w = w * (C / w.sum())
        self.register_buffer("class_weights", w)
        self.ls = label_smoothing

    def forward(self, logits, targets):
        return F.cross_entropy(
            logits, targets, weight=self.class_weights, label_smoothing=self.ls
        )


class FocalLoss(nn.Module):
    """Original focal loss [35]: L = - alpha * (1 - p_c)^gamma * log(p_c)."""

    def __init__(self, alpha: float = 0.25, gamma: float = 2.0,
                 num_classes: int = 5, label_smoothing: float = 0.0) -> None:
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.num_classes = num_classes
        self.ls = label_smoothing

    def forward(self, logits, targets):
        C = self.num_classes
        with torch.no_grad():
            one_hot = F.one_hot(targets, C).float()
            if self.ls > 0:
                one_hot = one_hot * (1 - self.ls) + self.ls / C
        log_p = F.log_softmax(logits, dim=-1)
        p = log_p.exp()
        p_t = (p * one_hot).sum(dim=-1)
        focal = (1 - p_t).clamp(min=1e-8) ** self.gamma
        ce = -(one_hot * log_p).sum(dim=-1)
        return (self.alpha * focal * ce).mean()


class ClassBalancedLoss(nn.Module):
    """Class-balanced loss based on effective number of samples [44]."""

    def __init__(self, class_counts: list, beta: float = 0.9999,
                 gamma: float = 2.0, num_classes: int = 5) -> None:
        super().__init__()
        n_c = torch.tensor(class_counts, dtype=torch.float32)
        eff_num = 1.0 - torch.pow(beta, n_c)
        w = (1.0 - beta) / eff_num
        w = w / w.sum() * num_classes
        self.register_buffer("class_weights", w)
        self.gamma = gamma
        self.num_classes = num_classes

    def forward(self, logits, targets):
        C = self.num_classes
        with torch.no_grad():
            one_hot = F.one_hot(targets, C).float()
        log_p = F.log_softmax(logits, dim=-1)
        p = log_p.exp()
        p_t = (p * one_hot).sum(dim=-1)
        focal = (1 - p_t).clamp(min=1e-8) ** self.gamma
        ce = -(one_hot * log_p).sum(dim=-1)
        w = self.class_weights[targets]
        return (w * focal * ce).mean()


class LDAMLoss(nn.Module):
    """Label-distribution-aware margin loss [45]."""

    def __init__(self, class_counts: list, max_m: float = 0.5, s: float = 30.0,
                 weight: Optional[torch.Tensor] = None) -> None:
        super().__init__()
        n_c = torch.tensor(class_counts, dtype=torch.float32)
        m_list = 1.0 / torch.sqrt(torch.sqrt(n_c))
        m_list = m_list * (max_m / m_list.max())
        self.register_buffer("m_list", m_list)
        self.s = s
        self.weight = weight

    def forward(self, logits, targets):
        index = torch.zeros_like(logits, dtype=torch.bool)
        index.scatter_(1, targets.view(-1, 1), True)
        batch_m = self.m_list[targets].unsqueeze(1)  # (B,1)
        logits_m = logits - batch_m * index.float()
        return F.cross_entropy(self.s * logits_m, targets, weight=self.weight)


# ============================================================
#  Factory
# ============================================================
def build_loss(name: str, class_counts: list, num_classes: int = 5,
               label_smoothing: float = 0.1, **kwargs) -> nn.Module:
    name = name.lower()
    if name in ("cwfl", "cwfl_loss"):
        return ClassAwareWeightedFocalLoss(
            class_counts, alpha=kwargs.get("alpha", 0.25),
            gamma=kwargs.get("gamma", 2.0),
            label_smoothing=label_smoothing,
        )
    if name in ("ce", "cross_entropy"):
        return StandardCrossEntropy(label_smoothing)
    if name in ("wce", "weighted_ce"):
        return WeightedCrossEntropy(class_counts, label_smoothing)
    if name in ("focal", "focal_loss", "fl"):
        return FocalLoss(alpha=kwargs.get("alpha", 0.25),
                         gamma=kwargs.get("gamma", 2.0),
                         num_classes=num_classes,
                         label_smoothing=label_smoothing)
    if name in ("cb", "cb_loss", "class_balanced"):
        return ClassBalancedLoss(class_counts, num_classes=num_classes)
    if name == "ldam":
        return LDAMLoss(class_counts)
    raise ValueError(f"Unknown loss: {name}")


LOSS_NAMES = ["ce", "wce", "focal", "cb", "ldam", "cwfl"]
