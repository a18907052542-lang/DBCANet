"""losses module."""
