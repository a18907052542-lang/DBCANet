"""DBCANet: Dual-Branch Cross-Attention Network for Tympanic Membrane Image Classification."""
__version__ = "1.0.0"
