"""
Grad-CAM (Selvaraju et al., 2017) for the visualization analysis in
Section 4.7 (lines 613-632, Figure 10).
"""
from __future__ import annotations

from typing import Optional
import numpy as np
import torch
import torch.nn.functional as F


class GradCAM:
    """Grad-CAM for any 2D convolutional feature map output."""

    def __init__(self, model: torch.nn.Module, target_layer: torch.nn.Module) -> None:
        self.model = model
        self.target_layer = target_layer
        self.activations = None
        self.gradients = None
        self._hooks = []
        self._register()

    def _register(self):
        def fwd_hook(_module, _input, output):
            self.activations = output.detach()

        def bwd_hook(_module, _grad_input, grad_output):
            self.gradients = grad_output[0].detach()

        self._hooks.append(self.target_layer.register_forward_hook(fwd_hook))
        self._hooks.append(self.target_layer.register_full_backward_hook(bwd_hook))

    def remove(self):
        for h in self._hooks:
            h.remove()
        self._hooks = []

    def __call__(self, input_tensor: torch.Tensor,
                 target_class: Optional[int] = None) -> np.ndarray:
        self.model.eval()
        logits = self.model(input_tensor)
        if target_class is None:
            target_class = int(logits.argmax(dim=1).item())
        self.model.zero_grad()
        score = logits[:, target_class].sum()
        score.backward(retain_graph=True)
        # Gradients : (B, C, H, W)  -> channel-mean weight (B, C, 1, 1)
        weights = self.gradients.mean(dim=(2, 3), keepdim=True)
        cam = (weights * self.activations).sum(dim=1, keepdim=True)
        cam = F.relu(cam)
        cam = F.interpolate(cam, size=input_tensor.shape[2:],
                            mode="bilinear", align_corners=False)
        cam = cam.squeeze().cpu().numpy()
        cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        return cam
