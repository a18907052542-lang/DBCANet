"""
Training loop for DBCANet and baselines.
Implements the two-stage backbone fine-tuning policy (lines 381-386):
  - Epochs 1-10  : freeze both backbones, train fusion + head only.
  - Epochs 11+   : joint fine-tuning with backbone lr scaled to 0.1x base.
Also implements early stopping on validation macro-F1 (lines 378-381) and
records the best checkpoint by validation macro-F1.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import time
import torch
import torch.nn as nn
import numpy as np
from sklearn.metrics import f1_score, accuracy_score

from .scheduler import CosineAnnealingWithMin


@dataclass
class TrainConfig:
    epochs: int = 100
    lr: float = 1e-4
    weight_decay: float = 5e-4
    eta_min: float = 1e-6
    freeze_backbone_epochs: int = 10
    backbone_lr_scale: float = 0.1
    early_stopping_patience: int = 15
    monitor: str = "val_macro_f1"
    device: str = "cuda" if torch.cuda.is_available() else "cpu"


@dataclass
class TrainState:
    best_val_f1: float = -1.0
    best_epoch: int = 0
    history: list = field(default_factory=list)
    no_improve_epochs: int = 0


def build_optimizer(model: nn.Module, cfg: TrainConfig, stage: int = 1):
    """Stage-1: only fusion+head trainable. Stage-2: joint fine-tuning."""
    if hasattr(model, "get_backbone_params") and hasattr(model, "get_head_and_fusion_params"):
        if stage == 1:
            params = [{"params": model.get_head_and_fusion_params(), "lr": cfg.lr}]
        else:
            params = [
                {"params": model.get_backbone_params(), "lr": cfg.lr * cfg.backbone_lr_scale},
                {"params": model.get_head_and_fusion_params(), "lr": cfg.lr},
            ]
    else:
        params = [{"params": [p for p in model.parameters() if p.requires_grad], "lr": cfg.lr}]
    return torch.optim.AdamW(params, lr=cfg.lr, weight_decay=cfg.weight_decay)


@torch.no_grad()
def evaluate(model, loader, device) -> dict:
    model.eval()
    all_p, all_t = [], []
    for x, y in loader:
        x = x.to(device, non_blocking=True)
        y = y.to(device, non_blocking=True)
        logits = model(x)
        all_p.append(logits.argmax(dim=1).cpu().numpy())
        all_t.append(y.cpu().numpy())
    p = np.concatenate(all_p)
    t = np.concatenate(all_t)
    return {
        "accuracy": accuracy_score(t, p),
        "macro_f1": f1_score(t, p, average="macro"),
        "preds": p,
        "targets": t,
    }


def train(
    model: nn.Module,
    train_loader,
    val_loader,
    loss_fn: nn.Module,
    cfg: TrainConfig,
    ckpt_path: Optional[str] = None,
    verbose: bool = True,
) -> TrainState:
    device = cfg.device
    model.to(device)
    loss_fn.to(device)
    state = TrainState()

    # Stage 1: freeze backbones
    if hasattr(model, "freeze_backbones"):
        model.freeze_backbones()
    optimizer = build_optimizer(model, cfg, stage=1)
    scheduler = CosineAnnealingWithMin(optimizer, T_max=cfg.epochs, eta_min=cfg.eta_min)

    for epoch in range(1, cfg.epochs + 1):
        # Transition to stage 2 (joint fine-tuning)
        if epoch == cfg.freeze_backbone_epochs + 1 and hasattr(model, "unfreeze_backbones"):
            model.unfreeze_backbones()
            optimizer = build_optimizer(model, cfg, stage=2)
            scheduler = CosineAnnealingWithMin(
                optimizer, T_max=cfg.epochs - cfg.freeze_backbone_epochs,
                eta_min=cfg.eta_min,
            )

        model.train()
        running_loss = 0.0
        n_batches = 0
        for x, y in train_loader:
            x = x.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            logits = model(x)
            loss = loss_fn(logits, y)
            loss.backward()
            optimizer.step()
            running_loss += float(loss.item())
            n_batches += 1
        scheduler.step()
        train_loss = running_loss / max(n_batches, 1)

        val_metrics = evaluate(model, val_loader, device)
        state.history.append({
            "epoch": epoch,
            "train_loss": train_loss,
            "val_accuracy": val_metrics["accuracy"],
            "val_macro_f1": val_metrics["macro_f1"],
        })
        improved = val_metrics["macro_f1"] > state.best_val_f1
        if improved:
            state.best_val_f1 = val_metrics["macro_f1"]
            state.best_epoch = epoch
            state.no_improve_epochs = 0
            if ckpt_path is not None:
                Path(ckpt_path).parent.mkdir(parents=True, exist_ok=True)
                torch.save({"model": model.state_dict(), "epoch": epoch,
                            "val_macro_f1": state.best_val_f1}, ckpt_path)
        else:
            state.no_improve_epochs += 1

        if verbose:
            print(f"[Epoch {epoch:3d}] loss={train_loss:.4f} "
                  f"val_acc={val_metrics['accuracy']*100:.2f}% "
                  f"val_F1={val_metrics['macro_f1']*100:.2f}% "
                  f"{'*' if improved else ''}")

        if state.no_improve_epochs >= cfg.early_stopping_patience:
            if verbose:
                print(f"Early stopping at epoch {epoch} "
                      f"(no improvement for {cfg.early_stopping_patience} epochs)")
            break

    return state
