"""Cosine annealing learning rate schedule (Methodology lines 375-377)."""
from __future__ import annotations

import math
from typing import List
import torch


class CosineAnnealingWithMin:
    """Wrapper around torch's CosineAnnealingLR with eta_min."""

    def __init__(self, optimizer: torch.optim.Optimizer,
                 T_max: int = 100, eta_min: float = 1e-6) -> None:
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=T_max, eta_min=eta_min,
        )

    def step(self):
        self.scheduler.step()

    def get_last_lr(self) -> List[float]:
        return self.scheduler.get_last_lr()
