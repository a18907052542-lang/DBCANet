"""training module."""
