"""
DBCANet — Dual-Branch Cross-Attention Network.
Top-level model assembling: CNN branch + Transformer branch + dimension
alignment + bidirectional cross-attention fusion + classification head.
Matches Methodology Section 3 (lines 223-398).
"""
from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from .cnn_branch import CNNBranch
from .transformer_branch import TransformerBranch
from .cross_attention import (
    CrossAttentionFusion,
    DimensionAligner,
    UnidirectionalCrossAttentionFusion,
)


class ClassificationHead(nn.Module):
    """
    Classification head (Section 3.4, Figure 6, lines 339-353).
    F_fuse (B, 256, 7, 7) -> GAP -> 256-dim v -> FC(256->512) -> BN -> ReLU
    -> Dropout(0.3) -> FC(512->num_classes) -> logits.
    """

    def __init__(self, in_channels: int = 256, hidden: int = 512,
                 num_classes: int = 5, dropout: float = 0.3) -> None:
        super().__init__()
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Linear(in_channels, hidden)
        self.bn = nn.BatchNorm1d(hidden)
        self.act = nn.ReLU(inplace=True)
        self.drop = nn.Dropout(dropout)
        self.fc2 = nn.Linear(hidden, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.gap(x).flatten(1)
        x = self.fc1(x)
        x = self.bn(x)
        x = self.act(x)
        x = self.drop(x)
        return self.fc2(x)


def xavier_init_module(m: nn.Module) -> None:
    """Xavier uniform initialization (Methodology lines 386-389)."""
    if isinstance(m, (nn.Linear, nn.Conv2d)):
        nn.init.xavier_uniform_(m.weight)
        if m.bias is not None:
            nn.init.zeros_(m.bias)


class DBCANet(nn.Module):
    """
    Top-level DBCANet model.
    Args:
        num_classes      : number of disease categories (5).
        unified_channels : C in the unified feature space (256).
        unified_spatial  : H = W of the unified feature map (7).
        num_heads        : number of cross-attention heads h (8).
        dropout          : classification head dropout (0.3).
        fusion_mode      : one of "bidirectional", "c2t", "t2c",
                           "concat", "add", "cnn_only", "trans_only".
                           Used to instantiate the ablation variants
                           A1-A8 in Table 6.
        pretrained       : whether to use ImageNet-pretrained backbones.
    """

    def __init__(
        self,
        num_classes: int = 5,
        unified_channels: int = 256,
        unified_spatial: int = 7,
        num_heads: int = 8,
        classifier_hidden: int = 512,
        dropout: float = 0.3,
        fusion_mode: str = "bidirectional",
        pretrained: bool = True,
    ) -> None:
        super().__init__()
        self.fusion_mode = fusion_mode
        self.unified_channels = unified_channels
        self.unified_spatial = unified_spatial

        # Single-branch variants (A1, A2) for ablation
        if fusion_mode == "cnn_only":
            self.cnn_branch = CNNBranch(pretrained=pretrained)
            self.align_cnn = DimensionAligner(self.cnn_branch.out_channels,
                                              unified_channels, unified_spatial)
            self.head = ClassificationHead(unified_channels, classifier_hidden,
                                           num_classes, dropout)
            self.head.apply(xavier_init_module)
            self.align_cnn.apply(xavier_init_module)
            return
        if fusion_mode == "trans_only":
            self.trans_branch = TransformerBranch(pretrained=pretrained)
            self.align_trans = DimensionAligner(self.trans_branch.out_channels,
                                                unified_channels, unified_spatial)
            self.head = ClassificationHead(unified_channels, classifier_hidden,
                                           num_classes, dropout)
            self.head.apply(xavier_init_module)
            self.align_trans.apply(xavier_init_module)
            return

        # Dual-branch variants
        self.cnn_branch = CNNBranch(pretrained=pretrained)
        self.trans_branch = TransformerBranch(pretrained=pretrained)
        self.align_cnn = DimensionAligner(self.cnn_branch.out_channels,
                                          unified_channels, unified_spatial)
        self.align_trans = DimensionAligner(self.trans_branch.out_channels,
                                            unified_channels, unified_spatial)

        if fusion_mode == "bidirectional":
            self.fusion = CrossAttentionFusion(unified_channels, num_heads, dropout=0.1)
        elif fusion_mode in ("c2t", "t2c"):
            self.fusion = UnidirectionalCrossAttentionFusion(
                unified_channels, num_heads, direction=fusion_mode, dropout=0.1
            )
        elif fusion_mode in ("concat", "add"):
            self.fusion = None  # handled inline
            if fusion_mode == "concat":
                self.concat_proj = nn.Conv2d(unified_channels * 2,
                                             unified_channels, kernel_size=1)
        else:
            raise ValueError(f"Unknown fusion_mode: {fusion_mode}")

        self.head = ClassificationHead(unified_channels, classifier_hidden,
                                       num_classes, dropout)
        for m in (self.align_cnn, self.align_trans, self.head):
            m.apply(xavier_init_module)
        if self.fusion is not None:
            self.fusion.apply(xavier_init_module)
        if fusion_mode == "concat":
            self.concat_proj.apply(xavier_init_module)

    def forward_features(self, x: torch.Tensor) -> torch.Tensor:
        """Returns the fused feature map F_fuse: (B, C, H, W)."""
        if self.fusion_mode == "cnn_only":
            f = self.cnn_branch(x)
            return self.align_cnn(f)
        if self.fusion_mode == "trans_only":
            f = self.trans_branch(x)
            return self.align_trans(f)

        f_cnn = self.cnn_branch(x)
        f_trans = self.trans_branch(x)
        f_cnn = self.align_cnn(f_cnn)
        f_trans = self.align_trans(f_trans)

        if self.fusion_mode == "bidirectional":
            return self.fusion(f_cnn, f_trans)
        if self.fusion_mode in ("c2t", "t2c"):
            return self.fusion(f_cnn, f_trans)
        if self.fusion_mode == "concat":
            return self.concat_proj(torch.cat([f_cnn, f_trans], dim=1))
        if self.fusion_mode == "add":
            return 0.5 * (f_cnn + f_trans)
        raise RuntimeError(f"Unhandled fusion_mode: {self.fusion_mode}")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        f = self.forward_features(x)
        return self.head(f)

    # ---- Two-stage fine-tuning support (Methodology lines 381-386) ----
    def freeze_backbones(self) -> None:
        if hasattr(self, "cnn_branch"):
            self.cnn_branch.freeze()
        if hasattr(self, "trans_branch"):
            self.trans_branch.freeze()

    def unfreeze_backbones(self) -> None:
        if hasattr(self, "cnn_branch"):
            self.cnn_branch.unfreeze()
        if hasattr(self, "trans_branch"):
            self.trans_branch.unfreeze()

    def get_backbone_params(self):
        params = []
        if hasattr(self, "cnn_branch"):
            params += list(self.cnn_branch.parameters())
        if hasattr(self, "trans_branch"):
            params += list(self.trans_branch.parameters())
        return params

    def get_head_and_fusion_params(self):
        params = list(self.head.parameters())
        if hasattr(self, "align_cnn"):
            params += list(self.align_cnn.parameters())
        if hasattr(self, "align_trans"):
            params += list(self.align_trans.parameters())
        if hasattr(self, "fusion") and self.fusion is not None:
            params += list(self.fusion.parameters())
        if hasattr(self, "concat_proj"):
            params += list(self.concat_proj.parameters())
        return params


def build_dbcanet(**kwargs) -> DBCANet:
    return DBCANet(**kwargs)


def count_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
