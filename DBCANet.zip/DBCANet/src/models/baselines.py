"""
Baseline models for the comparison study (Table 4, lines 470-471).
All baselines use ImageNet-1K pretrained weights and the same training pipeline.
"""
from __future__ import annotations

import torch
import torch.nn as nn

try:
    import timm
    _HAS_TIMM = True
except ImportError:
    _HAS_TIMM = False

from .cnn_branch import CNNBranch
from .transformer_branch import TransformerBranch
from .cross_attention import CrossAttentionFusion, DimensionAligner
from .dbcanet import ClassificationHead, xavier_init_module


def _timm_model(name: str, num_classes: int, pretrained: bool = True) -> nn.Module:
    if not _HAS_TIMM:
        raise ImportError("timm is required to build baseline models")
    return timm.create_model(name, pretrained=pretrained, num_classes=num_classes)


class TransFuseLike(nn.Module):
    """
    TransFuse-style baseline: dual CNN + Transformer branches with a
    unidirectional BiFusion-style multiplicative gating between intermediate
    features (Methodology comparison, lines 206-213).
    """

    def __init__(self, num_classes: int = 5, pretrained: bool = True,
                 unified_channels: int = 256, unified_spatial: int = 7) -> None:
        super().__init__()
        self.cnn = CNNBranch(pretrained=pretrained)
        self.trans = TransformerBranch(pretrained=pretrained)
        self.align_c = DimensionAligner(self.cnn.out_channels, unified_channels, unified_spatial)
        self.align_t = DimensionAligner(self.trans.out_channels, unified_channels, unified_spatial)
        # BiFusion-style gate
        self.gate = nn.Sequential(
            nn.Conv2d(unified_channels * 2, unified_channels, 1),
            nn.BatchNorm2d(unified_channels),
            nn.Sigmoid(),
        )
        self.fuse_proj = nn.Conv2d(unified_channels * 2, unified_channels, 1)
        self.head = ClassificationHead(unified_channels, 512, num_classes, 0.3)
        for m in (self.align_c, self.align_t, self.gate, self.fuse_proj, self.head):
            m.apply(xavier_init_module)

    def forward(self, x):
        fc = self.align_c(self.cnn(x))
        ft = self.align_t(self.trans(x))
        g = self.gate(torch.cat([fc, ft], dim=1))
        fused = self.fuse_proj(torch.cat([fc * g, ft * (1 - g)], dim=1))
        return self.head(fused)


class CrossViTLike(nn.Module):
    """
    CrossViT-style baseline: cross-attention restricted to class tokens
    of two granularity branches (Methodology comparison, lines 208-209).
    Approximated here by class-token-only attention between two backbones.
    """

    def __init__(self, num_classes: int = 5, pretrained: bool = True,
                 unified_channels: int = 256, unified_spatial: int = 7) -> None:
        super().__init__()
        self.cnn = CNNBranch(pretrained=pretrained)
        self.trans = TransformerBranch(pretrained=pretrained)
        self.align_c = DimensionAligner(self.cnn.out_channels, unified_channels, unified_spatial)
        self.align_t = DimensionAligner(self.trans.out_channels, unified_channels, unified_spatial)
        self.cls_c = nn.Parameter(torch.zeros(1, 1, unified_channels))
        self.cls_t = nn.Parameter(torch.zeros(1, 1, unified_channels))
        nn.init.trunc_normal_(self.cls_c, std=0.02)
        nn.init.trunc_normal_(self.cls_t, std=0.02)
        # Class-token-only cross-attention (much weaker than spatial-sequence CA)
        self.cross_c2t = nn.MultiheadAttention(unified_channels, num_heads=8,
                                               batch_first=True, dropout=0.1)
        self.cross_t2c = nn.MultiheadAttention(unified_channels, num_heads=8,
                                               batch_first=True, dropout=0.1)
        self.head = ClassificationHead(unified_channels, 512, num_classes, 0.3)
        self.head.apply(xavier_init_module)

    def forward(self, x):
        fc = self.align_c(self.cnn(x))
        ft = self.align_t(self.trans(x))
        B, C, H, W = fc.shape
        zc = fc.flatten(2).transpose(1, 2)  # (B, N, C)
        zt = ft.flatten(2).transpose(1, 2)
        cls_c = self.cls_c.expand(B, -1, -1)
        cls_t = self.cls_t.expand(B, -1, -1)
        # Concatenate class tokens with their own branch's patch tokens
        seq_c = torch.cat([cls_c, zc], dim=1)
        seq_t = torch.cat([cls_t, zt], dim=1)
        # Cross-attention is *only* on class tokens (CrossViT limitation)
        cls_c_new, _ = self.cross_c2t(cls_c, seq_t, seq_t)
        cls_t_new, _ = self.cross_t2c(cls_t, seq_c, seq_c)
        # Use averaged class tokens for classification
        cls = 0.5 * (cls_c_new.squeeze(1) + cls_t_new.squeeze(1))
        # Reshape to a 1x1 feature map for the standard head
        f = cls.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, H, W)
        return self.head(f)


class MedViTLike(nn.Module):
    """
    MedViT-style baseline [42] — robust ViT for medical image classification.
    Approximated by a vit_small with a 2D convolutional stem.
    """

    def __init__(self, num_classes: int = 5, pretrained: bool = True) -> None:
        super().__init__()
        self.model = _timm_model("vit_small_patch16_224", num_classes, pretrained)

    def forward(self, x):
        return self.model(x)


class HiFuseLike(nn.Module):
    """
    HiFuse-style baseline [43] — hierarchical multi-scale CNN-Transformer
    feature fusion. Approximated by a parallel CNN + Transformer with
    multi-stage concatenation.
    """

    def __init__(self, num_classes: int = 5, pretrained: bool = True,
                 unified_channels: int = 256, unified_spatial: int = 7) -> None:
        super().__init__()
        self.cnn = CNNBranch(pretrained=pretrained)
        self.trans = TransformerBranch(pretrained=pretrained)
        self.align_c = DimensionAligner(self.cnn.out_channels, unified_channels, unified_spatial)
        self.align_t = DimensionAligner(self.trans.out_channels, unified_channels, unified_spatial)
        # Hierarchical multi-scale fusion blocks
        self.fuse1 = nn.Sequential(
            nn.Conv2d(unified_channels * 2, unified_channels, 3, padding=1),
            nn.BatchNorm2d(unified_channels), nn.ReLU(inplace=True),
        )
        self.fuse2 = nn.Sequential(
            nn.Conv2d(unified_channels, unified_channels, 3, padding=1),
            nn.BatchNorm2d(unified_channels), nn.ReLU(inplace=True),
        )
        self.head = ClassificationHead(unified_channels, 512, num_classes, 0.3)
        for m in (self.align_c, self.align_t, self.fuse1, self.fuse2, self.head):
            m.apply(xavier_init_module)

    def forward(self, x):
        fc = self.align_c(self.cnn(x))
        ft = self.align_t(self.trans(x))
        f = self.fuse1(torch.cat([fc, ft], dim=1))
        f = self.fuse2(f) + f  # residual
        return self.head(f)


def build_baseline(name: str, num_classes: int = 5, pretrained: bool = True) -> nn.Module:
    """Factory for baseline models (Table 4)."""
    name = name.lower()
    if name == "resnet50":
        return _timm_model("resnet50", num_classes, pretrained)
    if name == "efficientnet_b4":
        return _timm_model("tf_efficientnet_b4", num_classes, pretrained)
    if name == "densenet121":
        return _timm_model("densenet121", num_classes, pretrained)
    if name in ("vit_base", "vit_base_patch16_224"):
        return _timm_model("vit_base_patch16_224", num_classes, pretrained)
    if name in ("swin_t", "swin_tiny"):
        return _timm_model("swin_tiny_patch4_window7_224", num_classes, pretrained)
    if name in ("convnext_t", "convnext_tiny"):
        return _timm_model("convnext_tiny", num_classes, pretrained)
    if name == "transfuse":
        return TransFuseLike(num_classes, pretrained)
    if name in ("crossvit", "crossvit_s"):
        return CrossViTLike(num_classes, pretrained)
    if name == "medvit":
        return MedViTLike(num_classes, pretrained)
    if name == "hifuse":
        return HiFuseLike(num_classes, pretrained)
    raise ValueError(f"Unknown baseline: {name}")


BASELINE_NAMES = [
    "resnet50", "efficientnet_b4", "densenet121", "vit_base", "swin_t",
    "convnext_t", "transfuse", "crossvit_s", "medvit", "hifuse",
]
