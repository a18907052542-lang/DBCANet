"""
Bidirectional Multi-Head Cross-Attention Fusion Module.
Implements Methodology Eq. (1)-(4) at lines 295-328 of the manuscript.

Symbols (exactly as in the paper):
    Z_c, Z_t : flattened sequences (B, N, C), N = H*W = 49, C = 256.
    Q_c = Z_c W^Q_c,  K_t = Z_t W^K_t,  V_t = Z_t W^V_t      (Eq. 1)
    CA_{c->t} = softmax(Q_c K_t^T / sqrt(d_k)) V_t            (Eq. 1)
    CA_{t->c} = softmax(Q_t K_c^T / sqrt(d_k)) V_c            (Eq. 2)
    MHCA = Concat(head_1, ..., head_h) W^O                    (Eq. 3)
    F_fuse = 1/2 ( F_hat_cnn + F_hat_trans )                  (Eq. 4)

Key design choices (lines 209-218):
    - Symmetric bidirectional QKV computed on the FULL N x C spatial sequence.
    - Dual residual + LayerNorm + FFN structure on each pathway.
    - Element-wise averaging prevents either branch from dominating.
"""
from __future__ import annotations

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class DimensionAligner(nn.Module):
    """
    Align two feature maps to a unified channel C and spatial size H_u x W_u
    via 1x1 convolution + bilinear interpolation (Methodology lines 269-273).
    """

    def __init__(self, in_channels: int, out_channels: int, out_size: int) -> None:
        super().__init__()
        self.proj = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.out_size = out_size

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.proj(x)
        x = self.bn(x)
        x = F.relu(x, inplace=True)
        if x.shape[-1] != self.out_size:
            x = F.interpolate(x, size=(self.out_size, self.out_size),
                              mode="bilinear", align_corners=False)
        return x


class MultiHeadCrossAttention(nn.Module):
    """
    One direction of multi-head cross-attention (Eq. 1 or Eq. 2).
    Implements: out = Concat(head_1, ..., head_h) W^O
                head_i = softmax(Q_i K_i^T / sqrt(d_k)) V_i
    Query is taken from one branch; Key/Value from the other branch.
    """

    def __init__(self, embed_dim: int = 256, num_heads: int = 8,
                 attn_dropout: float = 0.0, proj_dropout: float = 0.0) -> None:
        super().__init__()
        assert embed_dim % num_heads == 0, \
            f"embed_dim ({embed_dim}) must be divisible by num_heads ({num_heads})"
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads  # d_k = C / h
        self.scale = 1.0 / math.sqrt(self.head_dim)

        # Independent linear projections for Q (from one branch) and K, V (from the other)
        self.W_q = nn.Linear(embed_dim, embed_dim, bias=True)
        self.W_k = nn.Linear(embed_dim, embed_dim, bias=True)
        self.W_v = nn.Linear(embed_dim, embed_dim, bias=True)
        self.W_o = nn.Linear(embed_dim, embed_dim, bias=True)  # Output projection W^O

        self.attn_drop = nn.Dropout(attn_dropout)
        self.proj_drop = nn.Dropout(proj_dropout)

    def forward(self, query_src: torch.Tensor, kv_src: torch.Tensor) -> torch.Tensor:
        """
        query_src: (B, N, C) — provides Q (e.g. CNN features for CA_{c->t}).
        kv_src   : (B, N, C) — provides K, V (e.g. Transformer features).
        returns  : (B, N, C) — enhanced feature sequence.
        """
        B, N, C = query_src.shape
        h, d = self.num_heads, self.head_dim

        Q = self.W_q(query_src).reshape(B, N, h, d).transpose(1, 2)  # (B, h, N, d)
        K = self.W_k(kv_src).reshape(B, N, h, d).transpose(1, 2)
        V = self.W_v(kv_src).reshape(B, N, h, d).transpose(1, 2)

        attn = (Q @ K.transpose(-2, -1)) * self.scale          # (B, h, N, N)
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        out = attn @ V                                          # (B, h, N, d)
        out = out.transpose(1, 2).reshape(B, N, C)              # Concat heads
        out = self.W_o(out)                                     # W^O projection
        out = self.proj_drop(out)
        return out


class FFN(nn.Module):
    """Feed-forward network: Linear -> GELU -> Dropout -> Linear -> Dropout."""

    def __init__(self, dim: int, mlp_ratio: float = 4.0, dropout: float = 0.1) -> None:
        super().__init__()
        hidden = int(dim * mlp_ratio)
        self.fc1 = nn.Linear(dim, hidden)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden, dim)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


class CrossAttentionFusion(nn.Module):
    """
    Bidirectional Cross-Attention Fusion (Section 3.3, Figures 4 & 5).
    Two symmetric pathways:
        CA_{c->t}: CNN provides Q, Transformer provides K,V  -> F_hat_cnn
        CA_{t->c}: Transformer provides Q, CNN provides K,V  -> F_hat_trans
    Each pathway has its own residual + LayerNorm + FFN block.
    Final fusion is element-wise averaging (Eq. 4).
    """

    def __init__(self, embed_dim: int = 256, num_heads: int = 8,
                 mlp_ratio: float = 4.0, dropout: float = 0.1) -> None:
        super().__init__()
        self.embed_dim = embed_dim
        # CNN -> Transformer (CA_{c->t}) pathway
        self.ca_c2t = MultiHeadCrossAttention(embed_dim, num_heads, dropout, dropout)
        self.ln1_c = nn.LayerNorm(embed_dim)
        self.ffn_c = FFN(embed_dim, mlp_ratio, dropout)
        self.ln2_c = nn.LayerNorm(embed_dim)
        # Transformer -> CNN (CA_{t->c}) pathway
        self.ca_t2c = MultiHeadCrossAttention(embed_dim, num_heads, dropout, dropout)
        self.ln1_t = nn.LayerNorm(embed_dim)
        self.ffn_t = FFN(embed_dim, mlp_ratio, dropout)
        self.ln2_t = nn.LayerNorm(embed_dim)

    def forward(self, F_cnn: torch.Tensor, F_trans: torch.Tensor) -> torch.Tensor:
        """
        F_cnn, F_trans : (B, C, H, W) with same shape, e.g. (B, 256, 7, 7).
        returns        : F_fuse (B, C, H, W) — Eq. (4).
        """
        B, C, H, W = F_cnn.shape
        N = H * W

        # Flatten to (B, N, C)
        z_c = F_cnn.flatten(2).transpose(1, 2).contiguous()
        z_t = F_trans.flatten(2).transpose(1, 2).contiguous()

        # CNN-to-Transformer pathway: query=z_c, key=value=z_t
        out_c = self.ca_c2t(z_c, z_t)         # Eq. (1)
        out_c = self.ln1_c(z_c + out_c)        # residual + LayerNorm
        out_c = self.ln2_c(out_c + self.ffn_c(out_c))  # FFN + residual + LayerNorm

        # Transformer-to-CNN pathway: query=z_t, key=value=z_c
        out_t = self.ca_t2c(z_t, z_c)         # Eq. (2)
        out_t = self.ln1_t(z_t + out_t)
        out_t = self.ln2_t(out_t + self.ffn_t(out_t))

        # Reshape back to (B, C, H, W)
        F_hat_cnn = out_c.transpose(1, 2).reshape(B, C, H, W)
        F_hat_trans = out_t.transpose(1, 2).reshape(B, C, H, W)

        # Symmetric averaging — Eq. (4)
        F_fuse = 0.5 * (F_hat_cnn + F_hat_trans)
        return F_fuse


class UnidirectionalCrossAttentionFusion(nn.Module):
    """Single-direction cross-attention (for ablation A5 / A6)."""

    def __init__(self, embed_dim: int = 256, num_heads: int = 8,
                 direction: str = "c2t", mlp_ratio: float = 4.0,
                 dropout: float = 0.1) -> None:
        super().__init__()
        assert direction in ("c2t", "t2c")
        self.direction = direction
        self.ca = MultiHeadCrossAttention(embed_dim, num_heads, dropout, dropout)
        self.ln1 = nn.LayerNorm(embed_dim)
        self.ffn = FFN(embed_dim, mlp_ratio, dropout)
        self.ln2 = nn.LayerNorm(embed_dim)

    def forward(self, F_cnn: torch.Tensor, F_trans: torch.Tensor) -> torch.Tensor:
        B, C, H, W = F_cnn.shape
        z_c = F_cnn.flatten(2).transpose(1, 2).contiguous()
        z_t = F_trans.flatten(2).transpose(1, 2).contiguous()
        if self.direction == "c2t":
            q_src, kv_src, residual = z_c, z_t, z_c
        else:
            q_src, kv_src, residual = z_t, z_c, z_t
        out = self.ca(q_src, kv_src)
        out = self.ln1(residual + out)
        out = self.ln2(out + self.ffn(out))
        return out.transpose(1, 2).reshape(B, C, H, W)
