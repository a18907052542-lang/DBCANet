"""
CNN branch — EfficientNet-B4 (Methodology lines 247-258).

Retains the first four stages of pre-trained EfficientNet-B4 as a feature
extractor; removes the original classification layer; outputs a local feature
map F_cnn of size (C_cnn, H_cnn, W_cnn).

For 224x224 inputs, EfficientNet-B4 Stage-4 outputs a feature map at
spatial resolution 7x7 (stride 32) with 1792 channels. We project it to
the unified spatial size 7x7 and unified channel C=256 in the dimension-
alignment step (cross_attention.DimensionAligner).
"""
from __future__ import annotations

import torch
import torch.nn as nn

try:
    import timm
    _HAS_TIMM = True
except ImportError:
    _HAS_TIMM = False


class CNNBranch(nn.Module):
    """EfficientNet-B4 feature extractor (first four stages)."""

    def __init__(self, pretrained: bool = True, out_indices: tuple = (4,)) -> None:
        super().__init__()
        if not _HAS_TIMM:
            raise ImportError("timm is required: pip install timm")
        # features_only returns a list of intermediate feature maps;
        # out_indices=(4,) gives the Stage-4 output (B, 1792, 7, 7)
        self.backbone = timm.create_model(
            "efficientnet_b4",
            pretrained=pretrained,
            features_only=True,
            out_indices=out_indices,
        )
        self.out_channels: int = self.backbone.feature_info.channels()[-1]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (B, 3, 224, 224) -> F_cnn: (B, C_cnn, H_cnn, W_cnn) ~ (B, 1792, 7, 7)."""
        feats = self.backbone(x)
        return feats[-1]

    @torch.no_grad()
    def freeze(self) -> None:
        for p in self.parameters():
            p.requires_grad = False

    def unfreeze(self) -> None:
        for p in self.parameters():
            p.requires_grad = True
