"""
Transformer branch — Swin-T (Methodology lines 259-268).

Employs Swin Transformer (tiny variant) as global feature extractor.
Inputs are divided into 4x4 patches, mapped via linear embedding, and pass
through four stages of W-MSA / SW-MSA alternation. The final stage outputs
a global feature map F_trans of size (C_trans, H_trans, W_trans).

For 224x224 inputs, Swin-T Stage-3 outputs (B, 768, 7, 7).
"""
from __future__ import annotations

import torch
import torch.nn as nn

try:
    import timm
    _HAS_TIMM = True
except ImportError:
    _HAS_TIMM = False


class TransformerBranch(nn.Module):
    """Swin Transformer Tiny feature extractor."""

    def __init__(self, pretrained: bool = True) -> None:
        super().__init__()
        if not _HAS_TIMM:
            raise ImportError("timm is required: pip install timm")
        # Swin-T with features_only returns hierarchical feature maps;
        # last stage gives (B, 768, 7, 7) for 224x224 input
        self.backbone = timm.create_model(
            "swin_tiny_patch4_window7_224",
            pretrained=pretrained,
            features_only=True,
        )
        ch_list = self.backbone.feature_info.channels()
        self.out_channels: int = ch_list[-1]

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (B, 3, 224, 224) -> F_trans: (B, 768, 7, 7)."""
        feats = self.backbone(x)
        f = feats[-1]
        # timm Swin returns NHWC in some versions; ensure NCHW
        if f.ndim == 4 and f.shape[1] not in (96, 192, 384, 768):
            f = f.permute(0, 3, 1, 2).contiguous()
        return f

    @torch.no_grad()
    def freeze(self) -> None:
        for p in self.parameters():
            p.requires_grad = False

    def unfreeze(self) -> None:
        for p in self.parameters():
            p.requires_grad = True
