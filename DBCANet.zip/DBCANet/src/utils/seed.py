"""Reproducibility utilities (seeds 42, 123, 2024 from Methodology lines 393-395)."""
import os
import random
import numpy as np
import torch


def set_seed(seed: int) -> None:
    """Set seeds for Python, NumPy, PyTorch, and CUDA random number generators."""
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


SEEDS = [42, 123, 2024]
