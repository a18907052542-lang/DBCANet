"""
Table export — writes CSV files for Tables 2-13 matching the manuscript.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

TABLES_DIR = Path("results/tables")
TABLES_DIR.mkdir(parents=True, exist_ok=True)


def _fmt(mean_std):
    """Format (mean, std) as 'mean ± std' for tables."""
    if isinstance(mean_std, tuple):
        return f"{mean_std[0]:.2f} ± {mean_std[1]:.2f}"
    return str(mean_std)


def write_table2():
    """
    Table 2 — Class distribution at both image and patient levels.
    Uses the canonical 7:1:2 patient-level split reported in the manuscript
    (line 434). The values match the published Table 2 exactly.
    """
    # Per-class (train_imgs/train_pts, val_imgs/val_pts, test_imgs/test_pts,
    # total_imgs/total_pts) — directly from manuscript Table 2 (line 434)
    table2_rows = [
        ("Normal", "1,124 / 612",  "160 / 87",  "322 / 175", "1,606 / 874"),
        ("COM",    "986 / 503",    "141 / 72",  "282 / 144", "1,409 / 719"),
        ("OME",    "672 / 358",    "96 / 51",   "192 / 102", "960 / 511"),
        ("Myring", "418 / 224",    "60 / 32",   "119 / 64",  "597 / 320"),
        ("Wax",    "452 / 247",    "64 / 35",   "128 / 70",  "644 / 352"),
        ("Total",  "3,652 / 1,944","521 / 277", "1,043 / 555","5,216 / 2,776"),
    ]
    out_csv = TABLES_DIR / "Table2_class_distribution.csv"
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Category", "Train Imgs/Pts", "Val Imgs/Pts",
                    "Test Imgs/Pts", "Total Imgs/Pts"])
        for row in table2_rows:
            w.writerow(row)
    return out_csv


def write_table3():
    from src.data.dataset import SOURCE_DEVICE_DIST, CLASS_NAMES
    out_csv = TABLES_DIR / "Table3_source_device_distribution.csv"
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Source", "Device", *CLASS_NAMES, "Subtotal"])
        col_totals = [0] * 5
        for src, dev, counts, sub in SOURCE_DEVICE_DIST:
            w.writerow([src, dev, *counts, sub])
            for i in range(5):
                col_totals[i] += counts[i]
        w.writerow(["Total", "—", *col_totals, sum(col_totals)])
    return out_csv


def write_table4():
    from src.evaluation.paper_results import TABLE4
    out_csv = TABLES_DIR / "Table4_overall_performance.csv"
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Method", "Acc", "Pre (Macro)", "Rec (Macro)", "F1 (Macro)",
                    "AUC (Macro)", "Params (M)", "p-value"])
        for m, d in TABLE4.items():
            p = d["p_value"]
            p_str = "—" if p is None else (f"{p:.0e}" if p < 0.001 else f"{p:.3f}")
            w.writerow([m, _fmt(d["acc"]), _fmt(d["pre"]), _fmt(d["rec"]),
                        _fmt(d["f1"]), _fmt(d["auc"]), d["params_M"], p_str])
    return out_csv


def write_table5():
    from src.evaluation.paper_results import TABLE5
    out_csv = TABLES_DIR / "Table5_classwise_f1.csv"
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Method", "Normal", "COM", "OME", "Myring", "Wax"])
        for m, d in TABLE5.items():
            w.writerow([m, _fmt(d["Normal"]), _fmt(d["COM"]),
                        _fmt(d["OME"]), _fmt(d["Myring"]), _fmt(d["Wax"])])
    return out_csv


def write_table6():
    from src.evaluation.paper_results import TABLE6
    out_csv = TABLES_DIR / "Table6_ablation.csv"
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["ID", "Configuration", "Acc", "F1 (Macro)", "AUC (Macro)"])
        for k, d in TABLE6.items():
            w.writerow([k, d["config"], _fmt(d["acc"]), _fmt(d["f1"]), _fmt(d["auc"])])
    return out_csv


def write_table7():
    from src.evaluation.paper_results import TABLE7
    out_csv = TABLES_DIR / "Table7_hyperparameter.csv"
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Variable", "Setting", "Acc", "F1 (Macro)", "AUC (Macro)"])
        var_names = {"heads_h": "Number of heads h (d_k = C/h)",
                     "gamma": "Focusing parameter gamma",
                     "C": "Fused channel C"}
        for var, group in TABLE7.items():
            for setting, d in group.items():
                w.writerow([var_names[var], setting,
                            _fmt(d["acc"]), _fmt(d["f1"]), _fmt(d["auc"])])
    return out_csv


def write_table8():
    from src.evaluation.paper_results import TABLE8
    out_csv = TABLES_DIR / "Table8_loss_comparison.csv"
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Loss Function", "Acc", "F1 (Macro)", "F1 (Myring)", "F1 (OME)"])
        for m, d in TABLE8.items():
            w.writerow([m, _fmt(d["acc"]), _fmt(d["f1"]),
                        _fmt(d["f1_Myring"]), _fmt(d["f1_OME"])])
    return out_csv


def write_table9():
    from src.evaluation.paper_results import TABLE9
    out_csv = TABLES_DIR / "Table9_external_validation.csv"
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Held-out source/device", "Swin-T", "TransFuse", "HiFuse", "DBCANet"])
        for k, d in TABLE9.items():
            w.writerow([k, _fmt(d["Swin-T"]), _fmt(d["TransFuse"]),
                        _fmt(d["HiFuse"]), _fmt(d["DBCANet"])])
    return out_csv


def write_table10():
    from src.evaluation.paper_results import TABLE10
    out_csv = TABLES_DIR / "Table10_degradation.csv"
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Degradation", "Level", "Swin-T", "TransFuse", "HiFuse", "DBCANet"])
        labels = {"baseline": "Baseline (no degradation)",
                  "gaussian_blur_1": "Gaussian blur", "gaussian_blur_2": "Gaussian blur",
                  "gaussian_blur_3": "Gaussian blur", "gaussian_blur_5": "Gaussian blur",
                  "motion_blur_5": "Motion blur", "motion_blur_10": "Motion blur",
                  "motion_blur_15": "Motion blur",
                  "defocus_3": "Defocus", "defocus_5": "Defocus", "defocus_7": "Defocus",
                  "noise_001": "Gaussian noise", "noise_003": "Gaussian noise",
                  "noise_005": "Gaussian noise",
                  "brightness_20": "Brightness shift", "brightness_40": "Brightness shift"}
        for k, d in TABLE10.items():
            w.writerow([labels[k], d["level"], _fmt(d["Swin-T"]), _fmt(d["TransFuse"]),
                        _fmt(d["HiFuse"]), _fmt(d["DBCANet"])])
    return out_csv


def write_table11():
    from src.evaluation.paper_results import TABLE11
    out_csv = TABLES_DIR / "Table11_efficiency.csv"
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Method", "Parameters (M)", "FLOPs (G)", "Inference Time (ms/image)"])
        for m, d in TABLE11.items():
            w.writerow([m, d["params_M"], d["flops_G"], d["ms_per_image"]])
    return out_csv


def write_table12():
    from src.evaluation.paper_results import TABLE12
    out_csv = TABLES_DIR / "Table12_calibration.csv"
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Method", "ECE (before T)", "MCE (before T)",
                    "ECE (after T)", "MCE (after T)", "Best T"])
        for m, d in TABLE12.items():
            w.writerow([m, _fmt(d["ece_before"]), _fmt(d["mce_before"]),
                        _fmt(d["ece_after"]), _fmt(d["mce_after"]), d["T"]])
    return out_csv


def write_table13():
    from src.evaluation.paper_results import TABLE13
    out_csv = TABLES_DIR / "Table13_referral.csv"
    with open(out_csv, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Threshold tau", "Coverage (%)", "Accuracy on auto-processed (%)",
                    "Referral rate (%)", "Recall of misclassified within referrals (%)"])
        for tau, d in TABLE13.items():
            w.writerow([tau, d["coverage"], d["acc_auto"],
                        d["referral_rate"], d["recall_miscls"]])
    return out_csv


def write_all_tables():
    paths = {
        "Table2":  write_table2(),
        "Table3":  write_table3(),
        "Table4":  write_table4(),
        "Table5":  write_table5(),
        "Table6":  write_table6(),
        "Table7":  write_table7(),
        "Table8":  write_table8(),
        "Table9":  write_table9(),
        "Table10": write_table10(),
        "Table11": write_table11(),
        "Table12": write_table12(),
        "Table13": write_table13(),
    }
    return paths
