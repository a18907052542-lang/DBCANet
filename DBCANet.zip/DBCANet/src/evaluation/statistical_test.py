"""
Statistical significance testing for Section 4.3 (lines 453-455).
Paired two-tailed t-test at significance level alpha = 0.05 between
DBCANet and each competing method across the three random-seed runs.
"""
from __future__ import annotations

from typing import Sequence
import numpy as np
from scipy import stats


def paired_t_test(a: Sequence[float], b: Sequence[float]) -> dict:
    """Two-tailed paired t-test on per-run metric values."""
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    if a.size != b.size:
        raise ValueError(f"shape mismatch: {a.size} vs {b.size}")
    if a.size < 2:
        return {"t": 0.0, "p": 1.0, "df": 0, "n": int(a.size)}
    t, p = stats.ttest_rel(a, b)
    return {
        "t": float(t),
        "p": float(p),
        "df": int(a.size - 1),
        "n": int(a.size),
        "mean_diff": float(a.mean() - b.mean()),
    }


def benjamini_hochberg(pvals: Sequence[float], alpha: float = 0.05) -> np.ndarray:
    """BH-FDR adjusted significance flags."""
    p = np.asarray(pvals, dtype=np.float64)
    n = len(p)
    order = np.argsort(p)
    ranks = np.empty(n, dtype=int)
    ranks[order] = np.arange(1, n + 1)
    adj = p * n / ranks
    return adj <= alpha
