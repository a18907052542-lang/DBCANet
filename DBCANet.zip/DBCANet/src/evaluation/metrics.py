"""
Evaluation metrics for the manuscript:
  Accuracy, Precision (macro), Recall (macro), F1 (macro), AUC (one-vs-rest macro).
Per-class F1 (Table 5), Confusion matrix (Figure 11).
"""
from __future__ import annotations

from typing import Optional, Sequence
import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, roc_curve,
)


def compute_metrics(targets: np.ndarray, preds: np.ndarray,
                    probs: Optional[np.ndarray] = None,
                    num_classes: int = 5) -> dict:
    """Compute all primary metrics for one run."""
    out = {
        "accuracy":  accuracy_score(targets, preds),
        "precision": precision_score(targets, preds, average="macro", zero_division=0),
        "recall":    recall_score(targets, preds, average="macro", zero_division=0),
        "f1":        f1_score(targets, preds, average="macro", zero_division=0),
        "f1_per_class": f1_score(targets, preds, average=None,
                                 labels=list(range(num_classes)), zero_division=0).tolist(),
    }
    if probs is not None:
        try:
            out["auc_macro"] = roc_auc_score(targets, probs, average="macro",
                                             multi_class="ovr", labels=list(range(num_classes)))
            out["auc_micro"] = roc_auc_score(targets, probs, average="micro",
                                             multi_class="ovr", labels=list(range(num_classes)))
        except Exception:
            out["auc_macro"] = float("nan")
            out["auc_micro"] = float("nan")
    return out


def aggregate_runs(per_run: list) -> dict:
    """Aggregate metrics across multiple runs into mean and std."""
    keys = [k for k in per_run[0].keys() if isinstance(per_run[0][k], (int, float))]
    summary = {}
    for k in keys:
        vals = np.array([r[k] for r in per_run], dtype=np.float64)
        summary[k + "_mean"] = float(vals.mean())
        summary[k + "_std"] = float(vals.std(ddof=0))
    # per_class
    if "f1_per_class" in per_run[0]:
        arr = np.array([r["f1_per_class"] for r in per_run])  # (n_runs, n_classes)
        summary["f1_per_class_mean"] = arr.mean(axis=0).tolist()
        summary["f1_per_class_std"] = arr.std(axis=0).tolist()
    return summary


def normalized_confusion_matrix(targets: np.ndarray, preds: np.ndarray,
                                 num_classes: int = 5) -> np.ndarray:
    cm = confusion_matrix(targets, preds, labels=list(range(num_classes)))
    cm = cm.astype(np.float64)
    row_sums = cm.sum(axis=1, keepdims=True)
    cm_norm = np.divide(cm, row_sums, out=np.zeros_like(cm), where=row_sums > 0)
    return cm_norm
