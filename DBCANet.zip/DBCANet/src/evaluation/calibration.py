"""
Calibration analysis (Section 4.6, lines 670-685).
- Expected Calibration Error (ECE) and Maximum Calibration Error (MCE)
  with 15 equally-spaced confidence bins.
- Temperature scaling: one-parameter post-hoc calibration fitted on
  validation set by minimizing NLL with LBFGS.
"""
from __future__ import annotations

from typing import Tuple
import numpy as np
import torch
import torch.nn.functional as F


def expected_calibration_error(
    probs: np.ndarray, targets: np.ndarray, n_bins: int = 15
) -> Tuple[float, float]:
    """Return (ECE, MCE) in [0, 1] units."""
    confidences = probs.max(axis=1)
    preds = probs.argmax(axis=1)
    accuracies = (preds == targets).astype(np.float64)

    bin_edges = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    mce = 0.0
    n = len(probs)
    for i in range(n_bins):
        lo, hi = bin_edges[i], bin_edges[i + 1]
        mask = (confidences > lo) & (confidences <= hi) if i > 0 else (confidences <= hi)
        if mask.sum() == 0:
            continue
        bin_conf = confidences[mask].mean()
        bin_acc = accuracies[mask].mean()
        gap = abs(bin_conf - bin_acc)
        ece += (mask.sum() / n) * gap
        mce = max(mce, gap)
    return float(ece), float(mce)


def reliability_diagram_bins(probs: np.ndarray, targets: np.ndarray,
                              n_bins: int = 15):
    """Return (bin_centers, bin_acc, bin_conf, bin_count) for plotting."""
    confidences = probs.max(axis=1)
    preds = probs.argmax(axis=1)
    accuracies = (preds == targets).astype(np.float64)
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    centers = (edges[:-1] + edges[1:]) / 2
    accs = np.zeros(n_bins)
    confs = np.zeros(n_bins)
    counts = np.zeros(n_bins, dtype=int)
    for i in range(n_bins):
        lo, hi = edges[i], edges[i + 1]
        mask = (confidences > lo) & (confidences <= hi) if i > 0 else (confidences <= hi)
        if mask.sum() > 0:
            accs[i] = accuracies[mask].mean()
            confs[i] = confidences[mask].mean()
            counts[i] = int(mask.sum())
    return centers, accs, confs, counts


def fit_temperature(val_logits: np.ndarray, val_targets: np.ndarray,
                    max_iter: int = 100) -> float:
    """Fit a scalar temperature T by minimizing NLL on the validation set."""
    logits = torch.tensor(val_logits, dtype=torch.float32)
    targets = torch.tensor(val_targets, dtype=torch.long)
    T = torch.ones(1, requires_grad=True)
    optimizer = torch.optim.LBFGS([T], lr=0.1, max_iter=max_iter)

    def _closure():
        optimizer.zero_grad()
        loss = F.cross_entropy(logits / T.clamp(min=1e-3), targets)
        loss.backward()
        return loss

    optimizer.step(_closure)
    return float(T.detach().item())


def apply_temperature(probs_or_logits: np.ndarray, temperature: float,
                      is_logits: bool = False) -> np.ndarray:
    if not is_logits:
        # Convert probs to logits via log
        eps = 1e-12
        logits = np.log(np.clip(probs_or_logits, eps, 1.0))
    else:
        logits = probs_or_logits
    logits_T = logits / max(temperature, 1e-3)
    e = np.exp(logits_T - logits_T.max(axis=1, keepdims=True))
    return e / e.sum(axis=1, keepdims=True)
