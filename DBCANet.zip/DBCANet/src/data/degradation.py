"""
Controlled image-degradation operators for the robustness analysis (Section
4.5, lines 571-612). Five categories with explicit intensity levels match
Table 10 (line 596):
    (i)   Gaussian blur,  sigma in {1, 2, 3, 5}
    (ii)  Motion blur,    kernel L in {5, 10, 15}, random orientation
    (iii) Defocus (disk), radius r in {3, 5, 7}
    (iv)  Gaussian noise, sigma_n in {0.01, 0.03, 0.05} on [0,1] scale
    (v)   Brightness shift, +/- 20%, +/- 40%
Degradations are applied AFTER deterministic eval transform (center crop)
and BEFORE normalization, so they operate on uint8 RGB pixel space.
"""
from __future__ import annotations

import math
import numpy as np
import torch
from PIL import Image
import cv2


def gaussian_blur(img: np.ndarray, sigma: float) -> np.ndarray:
    if sigma <= 0:
        return img
    k = max(3, int(2 * round(3 * sigma) + 1))
    return cv2.GaussianBlur(img, (k, k), sigmaX=sigma, sigmaY=sigma)


def motion_blur(img: np.ndarray, length: int, angle: float = None) -> np.ndarray:
    if length <= 1:
        return img
    if angle is None:
        angle = np.random.uniform(0, 180)
    kernel = np.zeros((length, length), dtype=np.float32)
    kernel[length // 2, :] = 1.0 / length
    M = cv2.getRotationMatrix2D((length / 2 - 0.5, length / 2 - 0.5), angle, 1.0)
    kernel = cv2.warpAffine(kernel, M, (length, length))
    kernel /= max(kernel.sum(), 1e-6)
    return cv2.filter2D(img, -1, kernel)


def defocus_blur(img: np.ndarray, radius: int) -> np.ndarray:
    if radius <= 0:
        return img
    size = 2 * radius + 1
    yy, xx = np.ogrid[-radius:radius + 1, -radius:radius + 1]
    mask = (xx ** 2 + yy ** 2) <= radius ** 2
    kernel = mask.astype(np.float32)
    kernel /= kernel.sum()
    return cv2.filter2D(img, -1, kernel)


def gaussian_noise(img: np.ndarray, sigma_n: float) -> np.ndarray:
    if sigma_n <= 0:
        return img
    noise = np.random.randn(*img.shape) * (sigma_n * 255.0)
    return np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)


def brightness_shift(img: np.ndarray, delta_pct: float) -> np.ndarray:
    shift = (delta_pct / 100.0) * 255.0
    return np.clip(img.astype(np.float32) + shift, 0, 255).astype(np.uint8)


DEGRADATION_SPECS = {
    "gaussian_blur": {"levels": [1, 2, 3, 5], "fn": gaussian_blur},
    "motion_blur":   {"levels": [5, 10, 15],  "fn": motion_blur},
    "defocus":       {"levels": [3, 5, 7],    "fn": defocus_blur},
    "gaussian_noise":{"levels": [0.01, 0.03, 0.05], "fn": gaussian_noise},
    "brightness":    {"levels": [20, 40],     "fn": brightness_shift},
}


def apply_degradation(img: Image.Image, kind: str, level) -> Image.Image:
    arr = np.array(img)
    fn = DEGRADATION_SPECS[kind]["fn"]
    if kind == "brightness":
        # ±delta means we randomly choose sign each call
        sign = np.random.choice([-1, 1])
        out = fn(arr, sign * float(level))
    else:
        out = fn(arr, level)
    return Image.fromarray(out)
