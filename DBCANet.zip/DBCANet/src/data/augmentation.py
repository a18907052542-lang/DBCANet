"""
Training-time data augmentation pipeline.
Implements the explicit probability assignments at lines 389-393 of the
manuscript:
    Random horizontal flipping        (p = 0.5)
    Random rotation within +/- 15 deg (p = 0.5)
    Color jittering, intensity 0.2    (p = 0.5)
    Random resized cropping, 0.8-1.0  (p = 0.5)
    Gaussian blur, sigma in [0.1, 1.0](p = 0.3)
ImageNet mean/std normalization is applied at the end (lines 242-245).
"""
from __future__ import annotations

import random
from typing import Tuple

import torchvision.transforms as T
import torchvision.transforms.functional as TF
from PIL import Image, ImageFilter

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


class RandomApplyP:
    def __init__(self, transform, p: float) -> None:
        self.transform = transform
        self.p = p

    def __call__(self, img):
        if random.random() < self.p:
            return self.transform(img)
        return img


class GaussianBlurPIL:
    def __init__(self, sigma_range: Tuple[float, float]) -> None:
        self.sigma_range = sigma_range

    def __call__(self, img: Image.Image) -> Image.Image:
        sigma = random.uniform(*self.sigma_range)
        return img.filter(ImageFilter.GaussianBlur(radius=sigma))


def build_train_transform(image_size: int = 224) -> T.Compose:
    return T.Compose([
        T.Resize((image_size, image_size)),
        RandomApplyP(T.RandomHorizontalFlip(p=1.0), p=0.5),
        RandomApplyP(T.RandomRotation(degrees=15), p=0.5),
        RandomApplyP(T.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2), p=0.5),
        RandomApplyP(T.RandomResizedCrop(size=image_size, scale=(0.8, 1.0)), p=0.5),
        RandomApplyP(GaussianBlurPIL((0.1, 1.0)), p=0.3),
        T.ToTensor(),
        T.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])


def build_eval_transform(image_size: int = 224) -> T.Compose:
    return T.Compose([
        T.Resize((int(image_size * 256 / 224), int(image_size * 256 / 224))),
        T.CenterCrop(image_size),
        T.ToTensor(),
        T.Normalize(IMAGENET_MEAN, IMAGENET_STD),
    ])
